<?php declare(strict_types=1);

namespace Jikan\JikanPHP\Exception;

use Throwable;

interface ApiException extends Throwable
{
}
