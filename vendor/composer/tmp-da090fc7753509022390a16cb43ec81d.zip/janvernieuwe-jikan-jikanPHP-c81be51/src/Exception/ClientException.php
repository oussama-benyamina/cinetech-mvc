<?php declare(strict_types=1);

namespace Jikan\JikanPHP\Exception;

interface ClientException extends ApiException
{
}
