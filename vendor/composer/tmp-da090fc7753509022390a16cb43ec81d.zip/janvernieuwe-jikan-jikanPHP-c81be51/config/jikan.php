<?php declare(strict_types=1);

return [
    'openapi-file' => 'https://raw.githubusercontent.com/jikan-me/jikan-rest/master/storage/api-docs/api-docs.json',
    'namespace'    => 'Jikan\JikanPHP',
    'directory'    => __DIR__ . '/../src',
];
