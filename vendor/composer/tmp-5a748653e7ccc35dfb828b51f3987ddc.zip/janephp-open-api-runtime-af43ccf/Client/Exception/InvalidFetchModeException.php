<?php

declare(strict_types=1);

namespace Jane\Component\OpenApiRuntime\Client\Exception;

class InvalidFetchModeException extends \RuntimeException
{
}
