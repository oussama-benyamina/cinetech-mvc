<?php
namespace Rs\Json\Pointer;

class InvalidJsonException extends \Exception
{
}
