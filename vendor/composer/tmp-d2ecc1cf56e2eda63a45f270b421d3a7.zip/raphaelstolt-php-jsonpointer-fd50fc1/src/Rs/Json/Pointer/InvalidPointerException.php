<?php
namespace Rs\Json\Pointer;

class InvalidPointerException extends \Exception
{
}
